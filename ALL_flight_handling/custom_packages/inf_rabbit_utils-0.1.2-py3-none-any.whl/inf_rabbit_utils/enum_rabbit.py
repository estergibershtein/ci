from enum import Enum


class EnumExchange(Enum):
    DEFAULT = ""
    DIRECT = "direct"
    FANOUT = "fanout"
    HEADERS = "headers"
    TOPIC = "topic"
