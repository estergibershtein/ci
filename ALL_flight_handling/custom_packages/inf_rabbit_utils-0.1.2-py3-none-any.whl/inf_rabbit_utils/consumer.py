import json
from typing import Callable
from .connection import Connection
from .producer import Producer
from .azLogger import create_logger

logger = create_logger(__name__)


class Consumer(Connection):
    def __init__(
        self,
        queue_name: str,
        callback: Callable[[dict], None],
        error_queue_name="errors_queue",
        host="localhost",
        port=5672,
        username="guest",
        password="guest",
    ):
        try:
            # Initialize the base Connection class with the provided RabbitMQ parameters
            super().__init__(queue_name, host, port, username, password)
            # Initialize the Producer for error messages
            self.errors_producer = Producer(
                error_queue_name, host, port, username, password
            )
            # Store the callback for consuming messages
            self.consume_message_callback = callback
        except Exception:
            logger.error(f"Error initializing consumer")
            raise

    def consume(self):
        try:
            logger.info(f"Start consuming from {self.queue_name} queue")
            self.channel.basic_qos(prefetch_count=1)
            self.channel.basic_consume(
                queue=self.queue_name,
                on_message_callback=self.callback,
                auto_ack=False
            )
            self.channel.start_consuming()
        except Exception as e:
            logger.error(f"Error consuming message: {e}")

    def callback(self, ch, method, properties, body):
        message = json.loads(body)
        try:
            self.consume_message_callback(message)
        except Exception as e:
            logger.error(f"Error consuming message: {e}")
            self.send_to_error_queue(message, method.routing_key, e)
        self.channel.basic_ack(delivery_tag=method.delivery_tag)

    def send_to_error_queue(self, message, queue_name, error):
        try:
            message_error = {
                "queue": queue_name,
                "message": message,
                "error": str(error),
            }
            self.errors_producer.publish(message_error)
        except Exception as e:
            logger.error(f"Error sending to error queue: {e}")
