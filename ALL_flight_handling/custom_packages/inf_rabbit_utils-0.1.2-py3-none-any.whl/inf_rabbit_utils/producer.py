import json
from .connection import Connection
from .enum_rabbit import EnumExchange
from .azLogger import create_logger

logger = create_logger(__name__)


class Producer(Connection):
    def __init__(
        self,
        queue_name: str,
        host="localhost",
        port=5672,
        username="guest",
        password="guest",
    ):
        try:
            # Initialize the base Connection class with the provided RabbitMQ parameters
            super().__init__(queue_name, host, port, username, password)
        except Exception:
            logger.error(f"Error initializing producer")
            raise

    def publish(self, message: dict):
        try:
            # Publish the message to the specified exchange and queue
            self.channel.basic_publish(
                exchange=EnumExchange.DEFAULT.value,
                routing_key=self.queue_name,
                body=json.dumps(message),
            )
        except Exception as e:
            logger.error(f"Error publishing message: {e}")
