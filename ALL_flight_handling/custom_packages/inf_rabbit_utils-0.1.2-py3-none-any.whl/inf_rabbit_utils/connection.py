import pika
from .azLogger import create_logger

logger = create_logger(__name__)


class Connection:
    def __init__(
        self,
        queue_name: str,
        host="localhost",
        port=5672,
        username="guest",
        password="guest",
    ):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.queue_name = queue_name

        try:
            # Establish RabbitMQ connection and channel
            self.connection = self.rabbit_connection()
            self.channel = self.connection.channel()
            # Declare a queue to ensure it exists
            self.channel.queue_declare(queue=self.queue_name, durable=True)
        except Exception:
            # Log any errors during connection setup
            logger.error(f"Error connecting to RabbitMQ")
            raise

    def rabbit_connection(self):
        # Create RabbitMQ connection parameters with credentials
        credentials = pika.PlainCredentials(self.username, self.password)
        parameters = pika.ConnectionParameters(
            host=self.host, port=self.port, credentials=credentials
        )
        # Establish and return the RabbitMQ connection
        return pika.BlockingConnection(parameters)

    def close_connection(self):
        try:
            # Close the RabbitMQ connection
            self.connection.close()
        except Exception as e:
            # Log any errors during connection closure
            logger.error(f"Error closing RabbitMQ connection: {e}")
