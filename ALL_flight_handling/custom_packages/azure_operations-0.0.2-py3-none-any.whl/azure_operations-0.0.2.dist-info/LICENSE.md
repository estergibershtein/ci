# SkyVar

## SkyVar License Agreement *(Confidential)*

> [2024] © SkyVar
> All Rights Reserved.

## Notice

You must agree to be bound by the terms of this agreement before you can access, install or use the
*source code* of any **SkyVar** software. If you do not accept the terms of the license agreement
for this, you may not access, install or use the software.

## Ownership of the Software

The enclosed software program *("SOFTWARE")* and the accompanying written materials are owned by
**SkyVar** and are protected by Israeli copyright laws, by laws of other nations, and by
international treaties. You must treat the SOFTWARE like any other copyrighted material.

The intellectual and technical concepts contained herein are proprietary to **SkyVar** and its
suppliers and may be covered by Israeli and Foreign Patents, patents in process, and are
protected by trade secret or copyright law.

## Distribution

Dissemination of this information or reproduction of this material is strictly forbidden unless
prior written permission is obtained from **SkyVar**.

## Technical Support on Source Code

Due to the complexity of software development, **SkyVar** does not provide technical support related
to the use of the Source Code in your applications, unless otherwise specified by contract.

## Limited Warranty

Although **SkyVar** has tested this program and reviewed the documentation, **SkyVar** makes no
warranty or representation, either expressed or implied, with respect to this SOFTWARE, its
quality, performance, merchantability, or fitness for a particular purpose.

As a result, this SOFTWARE is licensed *"AS-IS"*, and you are assuming the entire risk as to its
quality and performance. In no event will SSW be liable for direct, indirect, special, incidental,
or consequential damages resulting from the use, or inability to use this software or its
documentation.

The warranty and remedies set forth in this limited warranty are exclusive and in lieu of all
others, oral or written, expressed or implied.
