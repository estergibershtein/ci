import logging

 
class Copy:

    def __init__(self, blob_service_client):
        self.blob_service_client = blob_service_client

    def copy_blobs(self, source_container, source_file_name, target_container, target_folder_name):
        '''The function copies a specific file to the desired location.'''

        try:

            target_file_name = self.get_target_file_name(source_file_name, target_folder_name)

            source_file_client = self.get_blob_client(source_container, source_file_name)
            target_file_client = self.get_blob_client(target_container, target_file_name)

            target_file_client.start_copy_from_url(source_file_client.url)

            logging.info('file copied successfully')

        except Exception as e:
            logging.error(f'Copy failed: {str(e)}')
            raise ValueError(f'Copy failed: {str(e)}')

    def get_target_file_name(self, source_file_name, target_folder_name):
        '''The function returns the destination file name. '''

        if '/' in source_file_name:
            file_name = source_file_name.split('/')[-1]
            return f'{target_folder_name}/{file_name}'
        return f'{target_folder_name}/{source_file_name}'

    def duplicate_file_with_different_name(self, container_name, source_file_name, new_file_name):
        '''Generates the target file name for duplication by replacing the original file name with the new file name.'''

        try:
            target_file_name = self.get_target_file_name_for_duplicate(source_file_name, new_file_name)

            source_file_client = self.get_blob_client(container_name, source_file_name)
            target_file_client = self.get_blob_client(container_name, target_file_name)

            target_file_client.start_copy_from_url(source_file_client.url)

            logging.info('file copied successfully')

        except Exception as e:
            logging.error(f'Copy failed: {str(e)}')
            raise ValueError(str(e))

    def get_target_file_name_for_duplicate(self, source_file_name, new_file_name):
        '''The function returns the name of the target file to be copied. '''

        if '/' in source_file_name:
            folder_name = source_file_name[:source_file_name.rfind('/')]
            return f'{folder_name}/{new_file_name}'
        return new_file_name

    def get_blob_client(self, container_name, file_name):
        '''The function returns the blob client.'''

        return self.blob_service_client.get_blob_client(container=container_name, blob=file_name)
